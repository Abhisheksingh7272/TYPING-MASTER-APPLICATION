# TypeMaster
This is small application build using java GUI where in user can check his/her typing speed. This is basic implementation of MVC architecture and DP problem of LCS.
